=== Use-your-Drive ===
Requires at least: 3.9
Tested up to: 4.9.8
Requires PHP: 5.5

Say hello to the most popular WordPress Google Drive plugin! Use-your-Drive is a user-friendly, highly customizable, innovative Google Drive integration plugin for WordPress that displays your Google Drive files in a beautiful way. No coding skills required!

== Description ==

This plugin will help you to easily integrate Google Drive into your WordPress website or blog. Use-your-Drive allows you to view, download, delete, rename files & folders directly from a WordPress page. You can use Use-your-Drive as a File browser, Gallery, Audio- or Video-Player!

== Changelog ==
You can find the Release Notes in the [Documentation](https://www.wpcloudplugins.com/wp-content/plugins/use-your-drive/_documentation/index.html#releasenotes).